#include <stdio.h>
// #include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
  pid_t pid;
  pid_t ppid;

  uid_t uid;
  uid_t euid;

  gid_t gid;
  gid_t egid;

  printf("Je suis le processus de PID      : %d\n", getpid());
  printf("Mon père est le processus de PID : %d\n", getppid());
  printf("Mon UID                          : %d \n", getuid());
  printf("Mon EUID                         : %d \n", geteuid());
  printf("Mon GID                          : %d \n", getgid());
  printf("Mon EGID                         : %d \n", getegid());
 return 0;
}
