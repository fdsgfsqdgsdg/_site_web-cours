#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
  pid_t p = fork();

  printf("Valeur de fork = %d \n", p);

  switch (p) {
    case -1:
        printf("Echec du fork\n");
    break;

    case 0 : //processus fils
        printf("Je suis le processus fils : PID = %d, PPID = %d\n", getpid(), getppid());
    break;

    default: //processus père
        printf("Je suis le processus père : PID = %d, PPID = %d, PID fils = %d \n", getpid(), getppid(), p);
    break;
  }
  
  
 return 0;
}
