#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
  pid_t p = fork();
  pid_t ppid;

  uid_t uid;
  uid_t euid;

  gid_t gid;
  gid_t egid;

  printf("Valeur de fork = %d \n", p);

  switch (p) {
    case -1:
        printf("Echec du fork\n");
    break;

    case 0 : //processus fils
        printf("Je suis le processus de PID      : %d\n", getpid());
        printf("Mon père est le processus de PID : %d\n", getppid());
        printf("Mon UID                          : %d \n", getuid());
        printf("Mon EUID                         : %d \n", geteuid());
        printf("Mon GID                          : %d \n", getgid());
        printf("Mon EGID                         : %d \n", getegid());
    break;

    default: //processus père
        sleep(0.5);
        printf("Je suis le processus de PID      : %d\n", getpid());
        printf("Mon père est le processus de PID : %d\n", getppid());
        printf("Mon UID                          : %d \n", getuid());
        printf("Mon EUID                         : %d \n", geteuid());
        printf("Mon GID                          : %d \n", getgid());
        printf("Mon EGID                         : %d \n", getegid());
    break;
  }

 return 0;
}
