DROP DATABASE IF EXISTS Pokemons; -- supprimer la base seulement si elle existe avant
CREATE DATABASE Pokemons;
USE Pokemons; -- se connecter à la base

DROP TABLE IF EXISTS Defense; -- supprime les tables
DROP TABLE IF EXISTS Arene;
DROP TABLE IF EXISTS Apparition;
DROP TABLE IF EXISTS Emplacement;

