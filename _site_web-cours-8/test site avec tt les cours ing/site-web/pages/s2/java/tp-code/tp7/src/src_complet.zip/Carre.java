public class Carre extends FormeAabstraite {
    public Carre(double cote, Point centreGravite){
        super(centreGravite);
        this.cote=cote;
    }
}
