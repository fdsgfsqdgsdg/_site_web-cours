package Forme;

public interface PileForme {
    boolean vide();
    void empiler(Forme e);
    void depiler();
    Forme sommet();
    void creer();
}
