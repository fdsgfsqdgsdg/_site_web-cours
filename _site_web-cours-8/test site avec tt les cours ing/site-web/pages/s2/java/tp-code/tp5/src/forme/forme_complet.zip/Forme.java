package Forme;

public interface Forme {
    double calculerSurface();
}
