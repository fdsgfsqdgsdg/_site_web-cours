public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Pair<String, Integer> p = new Pair<>("abc", 2);
        System.out.println(p.toString());
    }
}