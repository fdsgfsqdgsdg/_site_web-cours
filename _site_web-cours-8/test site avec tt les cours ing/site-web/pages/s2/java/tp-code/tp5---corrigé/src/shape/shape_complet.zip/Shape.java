package shape;

public interface Shape {

	double area();

	boolean isBigger(Shape shape);

}
