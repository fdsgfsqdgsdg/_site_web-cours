public class ScrutinClosException extends RuntimeException {
    public ScrutinClosException (String msg) {
        super(msg);
    }
}
